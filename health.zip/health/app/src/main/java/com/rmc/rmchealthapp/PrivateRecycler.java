package com.rmc.rmchealthapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PrivateRecycler extends RecyclerView.Adapter<PrivateRecycler.Viewholder> {
    JSONArray allPrivateHspt;
    Context context;

    public PrivateRecycler(JSONArray allPrivateHspt, Context context) {
        this.allPrivateHspt = allPrivateHspt;
        this.context = context;
    }

    @NonNull
    @Override
    public PrivateRecycler.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout, parent, false);
        Viewholder holder = new Viewholder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PrivateRecycler.Viewholder holder, int position) {
        try {
            JSONObject one_govt = allPrivateHspt.getJSONObject(position);

            holder.hsptName.setText(one_govt.getString("Hospital Name"));
            holder.hsptAddr.setText(one_govt.getString("Address"));
            holder.hours.setText(one_govt.getString("Hours"));
            holder.contact.setText(one_govt.getString("Contact No"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return allPrivateHspt.length();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView hsptName,hsptAddr,hours, contact;
        LinearLayout linearLayout;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            hsptName = itemView.findViewById(R.id.hsptName);
            hsptAddr = itemView.findViewById(R.id.hsptAddr);
            hours = itemView.findViewById(R.id.hours);
            contact = itemView.findViewById(R.id.contact);


            linearLayout = itemView.findViewById(R.id.parent_recycler_layout);
        }
    }
}
