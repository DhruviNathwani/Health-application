package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Department extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
    }

    public void Ortho(View view) {
        Intent i = new Intent(Department.this,Orthopadic.class);
        startActivity(i);
    }

    public void dental(View view) {
        Intent i = new Intent(Department.this,Dental.class);
        startActivity(i);
    }
}
