package com.rmc.rmchealthapp;

class VolleyHelper {
    public static final String bloodBank = "http://www.grabrmc.dx.am/bloodbank.php";
    public static final String GovtHospital = "http://www.grabrmc.dx.am/govt.php";
    public static final String privatetHospital = "http://www.grabrmc.dx.am/private.php";
    public static final String clinic = "http://www.grabrmc.dx.am/clinics.php";
    public static final String food = "http://www.grabrmc.dx.am/govt.php";
    public static final String orthopadic = "http://www.grabrmc.dx.am/hospitalDepartment/ortho.php";
    public static final String Dental = "http://www.grabrmc.dx.am/hospitalDepartment/Dental.php";
}
