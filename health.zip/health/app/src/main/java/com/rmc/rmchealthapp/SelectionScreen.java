package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectionScreen extends AppCompatActivity {

    Button govtbtn,privatebtn,bloodbtn,foodbtn,newbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_screen);

        govtbtn = findViewById(R.id.govtbtn);
        privatebtn = findViewById(R.id.privatebtn);
        bloodbtn = findViewById(R.id.bloodbtn);
        foodbtn = findViewById(R.id.foodbtn);
        newbtn = findViewById(R.id.newbtn);

    }

    public void gov_data(View view) {
        Intent intent = new Intent(SelectionScreen.this, GovtActivity.class);
        startActivity(intent);

    }

    public void Private_data(View view) {
        Intent intent = new Intent(SelectionScreen.this, PrivateActivity.class);
        startActivity(intent);
    }

    public void blood_data(View view) {
        Intent intent = new Intent(SelectionScreen.this,BloodActivity.class);
        startActivity(intent);
    }

    public void clinic_Data(View view) {
        Intent intent = new Intent(SelectionScreen.this,ClinicActivity.class);
        startActivity(intent);
    }

    public void Food(View view) {
        Intent intent = new Intent(SelectionScreen.this,FoodActivity.class);
        startActivity(intent);
    }

    public void department(View view) {
        Intent i = new Intent(SelectionScreen.this,Department.class);
        startActivity(i);
    }

    public void Whatnew(View view) {
        Intent i = new Intent(SelectionScreen.this,WhatsNew.class);
        startActivity(i);
    }
}


