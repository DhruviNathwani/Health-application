package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Dental extends AppCompatActivity {

    TextView dental;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dental);

        dental = findViewById(R.id.dental);

        final RequestQueue requestQueue = Volley.newRequestQueue(Dental.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, VolleyHelper.orthopadic, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dental.setText(response);
                requestQueue.stop();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dental.setText(R.string.error_occurred);
                        error.printStackTrace();
                        requestQueue.stop();
                    }
                });
        requestQueue.add(stringRequest);
    }
    }

