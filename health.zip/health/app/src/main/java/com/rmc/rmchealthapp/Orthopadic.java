package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Orthopadic extends AppCompatActivity {

    TextView orthoview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orthopadic);

        orthoview = findViewById(R.id.orthodata);

        final RequestQueue requestQueue = Volley.newRequestQueue(Orthopadic.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, VolleyHelper.orthopadic, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                orthoview.setText(response);
                requestQueue.stop();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        orthoview.setText(R.string.error_occurred);
                        error.printStackTrace();
                        requestQueue.stop();
                    }
                });
        requestQueue.add(stringRequest);
    }
}
