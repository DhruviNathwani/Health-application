package com.rmc.rmchealthapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

public class BloodActivity extends AppCompatActivity {
    TextView contact;

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood);

        contact = findViewById(R.id.contact);

        final RequestQueue requestQueue = Volley.newRequestQueue(BloodActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, VolleyHelper.bloodBank, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray all_Blood = new JSONArray(response);
                    recyclerView = findViewById(R.id.showBloodHospitals);
                    BloodRecycle bloodRecycle = new BloodRecycle(getApplicationContext(), all_Blood);
                    recyclerView.setAdapter(bloodRecycle);
                    recyclerView.setLayoutManager(new LinearLayoutManager(BloodActivity.this));

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                requestQueue.stop();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                requestQueue.stop();
            }
        });
        requestQueue.add(stringRequest);

    }

    public void call(){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }


        String phonenumber = contact.getText().toString();
        Intent i = new Intent(Intent.ACTION_CALL);
        i.setData(Uri.parse("tel:"+ phonenumber));
        startActivity(i);

        Toast.makeText(getApplicationContext(),"Call Sent successfully", Toast.LENGTH_LONG).show();
    }
    }
