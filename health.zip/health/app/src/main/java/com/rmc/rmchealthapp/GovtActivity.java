package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

public class GovtActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView contact,Address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt);

        contact = findViewById(R.id.contact);
        Address = findViewById(R.id.hsptAddr);

        final RequestQueue requestQueue = Volley.newRequestQueue(GovtActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, VolleyHelper.GovtHospital, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray all_govt_hspt = new JSONArray(response);
                    recyclerView = findViewById(R.id.showGovtHospitals);
                    GovtRecycler govtRecycler = new GovtRecycler(getApplicationContext(), all_govt_hspt);
                    recyclerView.setAdapter(govtRecycler);
                    recyclerView.setLayoutManager(new LinearLayoutManager(GovtActivity.this));

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                requestQueue.stop();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();
                requestQueue.stop();
            }
        });
        requestQueue.add(stringRequest);

    }

    public void call(){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }


        String phonenumber = contact.getText().toString();
        Intent i = new Intent(Intent.ACTION_CALL);
        i.setData(Uri.parse("tel:"+ phonenumber));
        startActivity(i);

        Toast.makeText(getApplicationContext(),"Call Sent successfully", Toast.LENGTH_LONG).show();
    }

    public void Open_app(){
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps"));
        startActivity(intent);
    }
}
