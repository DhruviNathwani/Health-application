package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WhatsNew extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whats_new);
    }
}
