package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username,password;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.btnlogin);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().equals("admin") && (password.getText().toString().equals("12345"))){
                    Intent i = new Intent(MainActivity.this,SelectionScreen.class);
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this,"something wrong !",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void Do_register(View view) {
        Intent i = new Intent(MainActivity.this,Registration.class);
        startActivity(i);
    }
}
