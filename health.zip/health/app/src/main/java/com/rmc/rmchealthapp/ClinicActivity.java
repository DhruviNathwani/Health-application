package com.rmc.rmchealthapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

public class ClinicActivity extends AppCompatActivity {

    TextView contact;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic);

        contact = findViewById(R.id.contact);

        final RequestQueue requestQueue = Volley.newRequestQueue(ClinicActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, VolleyHelper.clinic, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.i("req", response);
                    JSONArray all_Clinic = new JSONArray(response);
                    recyclerView = findViewById(R.id.showClinicHospitals);
                    ClinicRecycler clinicRecycler = new ClinicRecycler(getApplicationContext(), all_Clinic);
                    recyclerView.setAdapter(clinicRecycler);
                    recyclerView.setLayoutManager(new LinearLayoutManager(ClinicActivity.this));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                requestQueue.stop();
            }
        });
        requestQueue.add(stringRequest);

    }

    public void call(){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }


        String phonenumber = contact.getText().toString();
        Intent i = new Intent(Intent.ACTION_CALL);
        i.setData(Uri.parse("tel:"+ phonenumber));
        startActivity(i);

        Toast.makeText(getApplicationContext(),"Call Sent successfully", Toast.LENGTH_LONG).show();
    }
}
